

```cpp
#include <iostream>
#include <vector>
#include <queue>

using namespace std;

int main() {
    int n, m;
    cin >> n >> m;

    vector<string> maze(n);
    for (int i = 0; i < n; ++i) {
        cin >> maze[i];
    }

    int start_row, start_col, end_row, end_col;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            if (maze[i][j] == 'S') {
                start_row = i;
                start_col = j;
            } else if (maze[i][j] == 'E') {
                end_row = i;
                end_col = j;
            }
        }
    }

    vector<vector<int>> dist(n, vector<int>(m, -1));
    queue<pair<int, int>> q;

    dist[start_row][start_col] = 0;
    q.push({start_row, start_col});

    int dr[] = {-1, 1, 0, 0};
    int dc[] = {0, 0, -1, 1};

    while (!q.empty()) {
        int row = q.front().first;
        int col = q.front().second;
        q.pop();

        for (int i = 0; i < 4; ++i) {
            int new_row = row + dr[i];
            int new_col = col + dc[i];

            if (new_row >= 0 && new_row < n && new_col >= 0 && new_col < m &&
                maze[new_row][new_col] != '#' && dist[new_row][new_col] == -1) {
                dist[new_row][new_col] = dist[row][col] + 1;
                q.push({new_row, new_col});
            }
        }
    }

    cout << dist[end_row][end_col] << endl;

    return 0;
}
```