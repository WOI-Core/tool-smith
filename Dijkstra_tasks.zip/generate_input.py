

```python
import random

def generate_maze(n, m, obstacle_prob):
    maze = [['.' for _ in range(m)] for _ in range(n)]
    for i in range(n):
        for j in range(m):
            if random.random() < obstacle_prob:
                maze[i][j] = '#'
    start_row = random.randint(0, n - 1)
    start_col = random.randint(0, m - 1)
    while maze[start_row][start_col] == '#':
        start_row = random.randint(0, n - 1)
        start_col = random.randint(0, m - 1)
    end_row = random.randint(0, n - 1)
    end_col = random.randint(0, m - 1)
    while maze[end_row][end_col] == '#' or (start_row == end_row and start_col == end_col):
        end_row = random.randint(0, n - 1)
        end_col = random.randint(0, m - 1)
    maze[start_row][start_col] = 'S'
    maze[end_row][end_col] = 'E'
    return maze, start_row, start_col, end_row, end_col

def generate_input(test_case):
    n = random.randint(5, 20)
    m = random.randint(5, 20)
    obstacle_prob = random.uniform(0.2, 0.4)
    maze, start_row, start_col, end_row, end_col = generate_maze(n, m, obstacle_prob)

    with open(f"input/input_{test_case:02d}.txt", "w") as f:
        f.write(f"{n} {m}\n")
        for row in maze:
            f.write("".join(row) + "\n")

for i in range(1, 11):
    generate_input(i)
```

